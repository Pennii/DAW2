const menuLateral = document.getElementById("menuLateral")

menuLateral.innerHTML += '<ul id="miga"><li><a href="inicio.html">Inicio</a> -> Adopta un gato</li></ul>'