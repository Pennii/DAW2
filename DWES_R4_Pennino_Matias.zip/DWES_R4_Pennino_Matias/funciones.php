<?php
//Conectamos con la base de datos
try {
    $conexion = new PDO("mysql:host=localhost;dbname=dwes", "root", "");
} catch (Exception $exc) {
    echo $exc->getTraceAsString();
}

//Funcion que saneara el texto que ingrese el usuario
function sanear_texto($campo) {
    $campo = trim($campo);
    $campo = strip_tags($campo);
    $campo = htmlspecialchars($campo);

    return $campo;
}

//Funcion que valida si el usuario esta en la base de datos
function validar_datos(array $datos) {
    global $conexion;
    foreach ($datos as $clave => $valor) {
        $datos[$clave] = sanear_texto($valor);
    }
    //Cambiamos la consulta para que solo devuelva la clave y compararla con la contraseña ingresada
    try {
        $consultarUsuario = $conexion->prepare("SELECT CONTRASENA FROM USUARIOS WHERE USUARIO = :login");
        $consultarUsuario->bindParam(":login", $datos["usuario"]);
        $consultarUsuario->execute();
    } catch (Exception $exc) {
        echo $exc->getMessage();
    }
    $fila = $consultarUsuario->fetch(PDO::FETCH_ASSOC);
    $resultado = $fila ? true : false;
    return $resultado;
}

//Funcion que devuelve en forma de array los productos que esten en stock
function obtener_productos() {
    global $conexion;
    $todosProductos = [];
    try {
        $productos = $conexion->query("SELECT * FROM PRODUCTO");
    } catch (Exception $exc) {
        echo $exc->getMessage();
    }
    while ($producto = $productos->fetch(PDO::FETCH_ASSOC)) {
        //Con obtener stock total sabremos si un producto esta en stock o no
        if (obtener_stock_total($producto["cod"])) {
            array_push($todosProductos, $producto);
        }
    }
    return $todosProductos;
}

//Validamos los productos que el usuario intentara cargar en la base de datos
function validar_productos($productos) {
    global $conexion;
    $todosProductos = [];
    try {
        $nombresProductos = $conexion->query("SELECT COD, NOMBRE_CORTO, PVP FROM PRODUCTO");
    } catch (Exception $exc) {
        echo $exc->getTraceAsString();
    }
    while ($productosValidos = $nombresProductos->fetch(PDO::FETCH_ASSOC)) {
        if (in_array($productosValidos["NOMBRE_CORTO"], $productos)) {
            array_push($todosProductos, $productosValidos);
        }
    }
    return count($todosProductos) == count($productos) ? $todosProductos : false;
}

//Funcion que realizara el proceso de compra
function comprar_productos($carro) {
    global $conexion;
    $compra = [];
    $compraInvalida = false;
    try {
        $stockActual = $conexion->query("SELECT producto, unidades FROM STOCK WHERE UNIDADES != 0");
    } catch (Exception $exc) {
        echo $exc->getTraceAsString();
    }
    //Si un producto tiene stock lo agregamos a un array auxiliar
    while ($stock = $stockActual->fetch(PDO::FETCH_ASSOC)) {
        //Verificamos que el producto no haya estado listado anteriormente en el array auxiliar
        if (in_array($stock["producto"], $carro) && !in_array($stock["producto"], $compra)) {
            array_push($compra, $stock["producto"]);
        }
    }
    if (count($compra) != count($carro)) {
      $compraInvalida = true;
    }
    //Si los arrays son del mismo tamaño podemos proceder con la compra
    if (!$compraInvalida) {
        foreach ($compra as $producto) {
            //Descontamos el stock de los productos seleccionados
            descontar_stock($producto);
        }
    }
    return $compraInvalida ? false : true;
}

//Funcion que descontara 1 unidad del porducto seleccionado
function descontar_stock($producto) {
    global $conexion;
    //Obtenemos la tienda de la cual descontaremos el stock, en orden ascendente
    if ($tienda = obtener_stock_total($producto)) {
        try {
            $actualizarStock = $conexion->exec("UPDATE STOCK SET UNIDADES = UNIDADES - 1  WHERE PRODUCTO = '$producto' AND TIENDA = '$tienda'");
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
    }
}

//Funcion que devolvera la primera tienda que tenga stock de un producto
function obtener_stock_total($producto) {
    global $conexion;
    $encontrado = false;
    try {
        //Obtenemos todos los registros de un producto 
        $stockActual = $conexion->query("SELECT * FROM STOCK WHERE PRODUCTO = '$producto'");
    } catch (Exception $exc) {
        echo $exc->getTraceAsString();
    }
    if ($stockActual) {
        //Si alguna tienda tiene stock entonces podremos usarla para la compra
        while (($stock = $stockActual->fetch(PDO::FETCH_ASSOC)) && !$encontrado) {
            if ($stock["unidades"]) {
                $encontrado = true;
                $tienda = $stock["tienda"];
            }
        }
    }

    return $encontrado ? $tienda : false;
}
