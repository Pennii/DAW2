<?php

session_start();
require_once './funciones.php';
if (filter_has_var(INPUT_POST, "iniciar")) {
    $datos = filter_input_array(INPUT_POST);
    //Validamos al usuario con la base de datos y si es correcto lo enviamos a productos
    if (validar_datos($datos)) {
        if (!isset($_SESSION["usuario"]) || $_SESSION["usuario"] != $datos["usuario"]) {
            session_destroy();
            session_start();
            $_SESSION["usuario"] = sanear_texto($datos["usuario"]);
        }

        header("Location: productos.php");
        //Si el usuario no esta en la base de datos se notificara el error
    } else {
        $mensajeLogin = "Los datos introducidos no son correctos";
        $ruta = "index.php?mensajeLogin=$mensajeLogin";
        header("Location: $ruta");
    }
    //Si el usuario intenta entrar desde la url lo reenviamos a la pagina de inicio
} else {
    header("Location: index.php");
    session_destroy();
}