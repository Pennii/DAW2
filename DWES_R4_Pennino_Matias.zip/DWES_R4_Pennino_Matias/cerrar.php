<?php
//Borramos los datos de sesion y volvemos a inicio
session_start();
session_destroy();
header("Location: index.php");