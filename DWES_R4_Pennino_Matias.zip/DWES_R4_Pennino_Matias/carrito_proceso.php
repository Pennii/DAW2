<?php

session_start();

require_once './funciones.php';
if (filter_has_var(INPUT_POST, "agregarProductos")) {
    /* Si el usuario agrega productos al carrito primero validamos que esos productos esten listados,
     * y si todo esta correcto cargamos el carro y volvemos a productos
     */
    $datos = filter_input_array(INPUT_POST);
    if (isset($datos["productos"])) {
        if ($carro = validar_productos($datos["productos"])) {
            $_SESSION["productos"] = $carro;
        }
    }
    header("Location: productos.php");
} else if (filter_has_var(INPUT_POST, "comprarProductos")) {
    /*  Si el usuario decide comprar los productos realizaremos el proceso y borramos
     *  los datos del carrito
     */
    $datos = filter_input_array(INPUT_POST);
    if (comprar_productos($datos["carro"])) {
        $mensaje = "Compra realizada con exito";
        unset($_SESSION["productos"]);
        /* Si no hay stock de productos, le avisamos de esto al usuario y lo devolvemos
         * a la pagina de productos
         */
    } else {
        $mensaje = "No se ha podido realizar la compra no todos los productos estan en stock";
    }
    header("Location: productos.php?mensaje=$mensaje");
} else if (filter_has_var(INPUT_POST, "cancelarCompra")) {
    //Si el usuario cancela la compra borramos los datos del carrito
    unset($_SESSION["productos"]);
    $mensaje = "Se han eliminado los productos del carrito";
    header("Location: productos.php?mensaje=$mensaje");
} else {
    header("Location: index.php");
}