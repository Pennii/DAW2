<?php
session_start();
//Verificamos que el usuario haya iniciado sesion antes de entrar
if (!isset($_SESSION["usuario"])) {
    header("Location: index.php");
}
require_once './funciones.php';
//Obtenemos los productos que tengan stock en la base de datos
$productos = obtener_productos();
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
            body{
                display: flex;
                justify-content: space-evenly;
                align-items: start;
            }
        </style>
    </head>
    <body>
        <div style="width: 60%">
            <form action="carrito_proceso.php" method="post">
                <table border="1" >
                    <tr>
                        <?php
                        //Imprimimos los productos
                        foreach ($productos[0] as $campoProducto => $valorCampo) {
                            if (in_array($campoProducto, ["nombre_corto", "descripcion", "PVP"])) {
                                ?>
                                <th><?php echo $campoProducto; ?></th>
                                <?php
                            }
                        }
                        ?>  
                    </tr>
                    <?php
                    foreach ($productos as $producto) {
                        ?>
                        <tr>
                            <?php
                            foreach ($producto as $campoProducto => $campo) {
                                if (in_array($campoProducto, ["nombre_corto", "descripcion", "PVP"])) {
                                    ?>
                                    <td><?php echo $campo; ?></td>
                                    <?php
                                }
                            }
                            ?>
                            <td>
                                <label>Agregar al carrito</label>
                                <input type="checkbox" name="productos[]" value="<?php echo $producto["nombre_corto"]; ?>">
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </table>
                <button name="agregarProductos">Agregar productos</button>
            </form>
            <a href="cerrar.php">Cerrar sesion</a>
        </div>
        <div>
            <?php
            //Si el usuario tiene productos en el carrito se mostrara a un lado de los productos listados
            if (isset($_SESSION["productos"])) {
                ?>
                <form action="carrito_proceso.php" method="post">
                    <table border="1" >
                        <tr>
                            <?php
                            foreach ($productos[0] as $campoProducto => $valorCampo) {
                                if (in_array($campoProducto, ["nombre_corto", "PVP"])) {
                                    ?>
                                    <th><?php echo $campoProducto; ?></th>
                                    <?php
                                }
                            }
                            ?>  
                        </tr>
                        <?php
                        foreach ($_SESSION["productos"] as $producto) {
                            ?>
                            <tr>
                                <?php
                                foreach ($producto as $campoProducto => $campo) {
                                    if (in_array($campoProducto, ["NOMBRE_CORTO", "PVP"])) {
                                        ?>
                                        <td><?php echo $campo; ?></td>
                                        <?php
                                    }
                                }
                                ?>
                            <input type="checkbox" name="carro[]" value="<?php echo $producto["COD"]; ?>" checked="checked" hidden>
                            </tr>
                            <?php
                        }
                        ?>
                    </table>
                    <button name="comprarProductos">Comprar</button>
                    <button name="cancelarCompra">Cancelar compra</button>
                </form>
                <?php
            }
            //Este mensaje le dara informacion al usuario de lo que haga con el carrito
            if (filter_has_var(INPUT_GET, "mensaje")) {
                ?><p style="color:blue"><?php echo filter_input(INPUT_GET, "mensaje"); ?></p>
                <?php
            }
            ?>
        </div>
    </body>
</html>
