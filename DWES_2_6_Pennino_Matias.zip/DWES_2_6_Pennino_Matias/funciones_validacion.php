<?php

/* validamos si la cadena ingresada es un texto, consideramos que puede escribirse
  mas de una palabra */

function validar_texto($campo) {
    //quitamos espacios del inicio y final
    $campo = trim($campo);
    //quitamos las etiquetas html y otros caracteres especiales
    $campo = filter_var($campo, FILTER_SANITIZE_STRING);

    return $campo;
}

//validamos si se ingreso una edad entre 5 y 99
function validar_edad($campo){
    //quitamos los espacios vacios
    $campo = trim($campo);
    //establecemos el rango de edad
    $rangos = ["options" => ["default" => 1, "min_range" => 5, "max_range" => 99]];
    //quitamos caracteres especiales
    $campo = filter_var($campo, FILTER_SANITIZE_NUMBER_INT);
    //validamos si es un entero en el rango
    $campo = filter_var($campo, FILTER_VALIDATE_INT, $rangos);

    
    return $campo;
}

//validamos si el sexo es valido
function validar_sexo($campo){
    $salida = false;
    //establecemos los sexos posibles
    $sexos = ["hombre", "mujer"];
    //validamos el texto
    $campo = validar_texto($campo);
    //si es valido devuelve el campo sino false
    $valido = in_array($campo, $sexos);
    if ($valido) {
        $salida = $campo;
    }
    return $salida;
}

function validar_aficion($campo){
    $salida = false;
    $invalido = false;
    $aficiones = ["deportes", "musica","alimentacion","moda"];
    foreach ($campo as  $value) {
        if (!in_array($value, $aficiones)) {
            $invalido = true;
        }
    }
    if (!$invalido) {
        $salida = "sale";
    }else{
        $salida = "no sale";
    }
    return $salida;
}

function validar_provincia($campo){   
 
}