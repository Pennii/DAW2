<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        try {
            $conexion = new mysqli("localhost", "root", "", "espectaculos");
        } catch (Exception $exc) {
            exit("No se ha podido conectar a la base de datos " . $exc->getMessage());
        }
        try {
            $consultaActores = $conexion->stmt_init();
            $consultaActores->prepare("SELECT NOMBRE FROM ACTOR;");
            $ejecutado = $consultaActores->execute();
        } catch (Exception $exc) {
            exit("Error al realizar la consulta de actores" . $exc->getMessage());
        }
        if ($ejecutado) {
            $resultado = $consultaActores->get_result();
            ?>
            <form method="get" action="<?php echo filter_input(INPUT_SERVER, "PHP_SELF"); ?>">
                <table border="1">
                    <?php
                    while ($fila = $resultado->fetch_row()) {
                        ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="actores[]" value="<?php echo $fila[0] ?>"> 
                            </td>
                            <td>
                                <?php echo $fila[0]; ?>
                            </td>

                        </tr>
                        <?php
                    }
                    ?>
                </table>
                <?php
                try {
                    $consultaEspectaculos = $conexion->stmt_init();
                    $consultaEspectaculos->prepare("SELECT NOMBRE FROM ESPECTACULO;");
                    $ejecutado = $consultaEspectaculos->execute();
                } catch (Exception $exc) {
                    exit("Error al realizar la consulta de espectaculos " . $exc->getMessage());
                }
                if ($ejecutado) {
                    ?>
                    <br>
                    <label>Seleccione un espectaculo</label>
                    <br>
                    <br>
                    <select name="espectaculo">
                        <?php
                        $resultado = $consultaEspectaculos->get_result();
                        while ($fila = $resultado->fetch_row()) {
                            ?>
                            <option value="<?php echo $fila[0]; ?>"><?php echo $fila[0]; ?></option>
                            <?php
                        }
                        ?>
                    </select>
                    <?php
                } else {
                    exit("No se ha podido mostrar la tabla de espectaculos");
                }
                ?>
                <br>
                <br>
                <button value="1" name="enviar">Enviar</button>
            </form>
            <?php
        } else {
            echo "No se ha podido mostrar una tabla de actores";
        }
        if (filter_input_array(INPUT_GET)) {
            try {
                $consultaCodigoActor = $conexion->stmt_init();
                $consultaCodigoActor->prepare("SELECT cdactor FROM ACTOR WHERE NOMBRE = ?;");
            } catch (Exception $exc) {
                echo $exc->getTraceAsString();
            }
        }
        ?>
    </body>
</html>
