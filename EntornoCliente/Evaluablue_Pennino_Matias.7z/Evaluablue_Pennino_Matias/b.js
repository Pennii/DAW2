
function crearArray() {
    var inicial = [{ make: "ford", model: "mustang", year: 1994 }]

    var convertido = [["make", inicial[0].make]["model", inicial[0].model] ["year",inicial[0].year]]
    alert(convertido)
}